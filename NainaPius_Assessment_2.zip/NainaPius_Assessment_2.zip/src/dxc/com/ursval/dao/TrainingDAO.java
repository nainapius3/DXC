package dxc.com.ursval.dao;



import java.util.List;

import com.dxc.usrval.model.Training;





public interface TrainingDAO {
	public static List<Training> getAllDetails() {
		// TODO Auto-generated method stub
		return null;
	}
}
