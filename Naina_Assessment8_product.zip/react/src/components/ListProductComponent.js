import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';


class ListProductComponent extends Component {

    constructor(props){
        super(props)
        this.refreshProduct=this.refreshProduct.bind(this);
        this.deleteProductClicked=this.deleteProductClicked.bind(this);
        this.updateProductClicked=this.updateProductClicked.bind(this);
        this.addProductClicked=this.addProductClicked.bind(this);
        this.searchProductClicked=this.searchProductClicked.bind(this);
        this.state={
            products:[],
            message:''

        }
    }

    componentWillMount(){
      this.refreshProduct();
           
    }

    refreshProduct(){
        ProductDataService.getAllProducts().then(
            response=>{
                this.setState({
                    products:response.data
                })
            }
         ) 

    }

    deleteProductClicked(productIdToDelete){
         ProductDataService.deleteProduct(productIdToDelete).then(response =>{
            
                this.setState({
                    message:'product Id '+productIdToDelete+'deleted successfully'
                })
                this.refreshProduct()
            
            }) 
        
    }

    updateProductClicked(productId){
        this.props.history.push(`/products/${productId}`)

    }

    addProductClicked(){
        console.log(" add button clicked")
        this.props.history.push('/products/ ')
    }

    searchProductClicked(){
        console.log("search button clicked")
        this.props.history.push('/productsearch')
    }
    render() {
        return (
            <div>
                
                <div className="container">
                    {this.state.message && <div className="alert alert-success">{this.state.message}
                    </div>}
                    <h2>All products for you</h2>
                    <div className="container">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>product Id</th>
                                    <th>product Name</th>
                                    <th>quantity on hand</th>
                                    <th>price</th>
                                    <th>Update</th>
                                    <th>Delete</th>
                                   
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.products.map(product =>
                                        <tr key={product.productId}
                                        >
                                            <td>{product.productId}</td>
                                            <td>{product.productName}</td>
                                            <td>{product.quantityOnHand}</td>
                                            <td>{product.price}</td>
                                            <td>
                                                <button className="btn btn-primary"
                                                onClick={()=>this.updateProductClicked(product.productId)}>Update</button>
                                            </td>
                                            <td>
                                                <button className="btn btn-danger"
                                                onClick={()=>this.deleteProductClicked(product.productId)}>Delete</button>
                                            </td>
                                           
                                        </tr>
                                        )
                                }
                            </tbody>
                        </table>
                        <button type="submit" className="btn btn-success"
                        onClick={()=>this.addProductClicked()}>Add product</button>

                        <button type="submit" className="btn btn-primary" 
                        onClick={()=>this.searchProductClicked()}>search</button>
                    </div>
                </div>
            </div>
        );
    }
}

export default ListProductComponent;