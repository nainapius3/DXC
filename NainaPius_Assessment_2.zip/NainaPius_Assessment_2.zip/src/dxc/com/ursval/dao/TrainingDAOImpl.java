package dxc.com.ursval.dao;




import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dxc.usrval.dbcom.DbConnection;
import com.dxc.usrval.model.Training;


public class TrainingDAOImpl implements TrainingDAO {
	Connection connection = DbConnection.getConnection();
	private static final String FETCH_TRAINING_ALL ="select * from training";
	public List<Training> getAllDetails() {
List<Training> allTraining=new ArrayList<Training>();
		
		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery(FETCH_TRAINING_ALL);
			while(res.next())
			{
				Training training = new Training();
				training.setSapId(res.getInt(1));
				training.setEmployeeName(res.getString(2));
				training.setStream(res.getString(3));
				training.setPercentage(res.getInt(4));
				allTraining.add(training);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allTraining;
	}

}

