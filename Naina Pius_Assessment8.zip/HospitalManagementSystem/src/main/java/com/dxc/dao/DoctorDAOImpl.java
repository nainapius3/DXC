package com.dxc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Doctor;
import com.dxc.util.HibernateUtil;

public abstract class DoctorDAOImpl implements DoctorDAO {
	
	
	
	
	
	SessionFactory sf=HibernateUtil.getSessionFactory();
	
	public Doctor getDoctor(int docId) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		Doctor doctor=(Doctor)session.get(Doctor.class,docId);
		return doctor;
	}

	public List<Doctor> getAllDoctors(String docName) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		Query query=session.getNamedQuery("findDoctorByName");
		query.setString("prodName",docName);
		return query.list();
		
	}


	

	public void addDoctor(Doctor doctor) {
		
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getDocId()+"saved succesfully");
		
	}

	public void deleteProduct(int docId) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
   		Transaction transaction=session.beginTransaction();
   		Doctor doctor=new Doctor();
   		doctor.setDocId(docId);
   		session.delete(doctor);
   		transaction.commit();
   		session.close();
		
	}

	public void updateDoctor(Doctor newDoctor) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(newDoctor);

		/* session.saveOrUpdate(newDoctor); */
		transaction.commit();
		session.close();
		
		
	}






 
	

}
