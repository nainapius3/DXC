package com.dxc.usrval.client;



public class Main {
	

	public static void main(String[] args) {
ValidationApp validationApp=new ValidationApp();
validationApp.launchApp();
	}

}
