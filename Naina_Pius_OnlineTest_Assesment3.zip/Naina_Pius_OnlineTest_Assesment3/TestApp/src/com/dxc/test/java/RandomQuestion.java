package com.dxc.test.java;

import java.util.Random;

public class RandomQuestion {

	public RandomQuestion() {
		// TODO Auto-generated constructor stub
	}
Random random=new Random();

}
