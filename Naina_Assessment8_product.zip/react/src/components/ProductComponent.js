import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import { Formik, Form,Field, ErrorMessage } from 'formik';

class ProductComponent extends Component {

    constructor(props){
        super(props);
        this.state=({
            productId:this.props.match.params.prodId,
            productName:'',
            quantityOnHand:'',
            price:'',
            j:'',
            text:''
        })
        this.onSubmit=this.onSubmit.bind(this)
    }

    componentWillMount(){
        if(this.state.productId===" "){
            this.setState({
                j:false,
                text:"save"
            })
            return;
        }
        ProductDataService.getProduct(this.state.productId).then(
            response =>{
                this.setState({
                    productName:response.data.productName,
                    quantityOnHand:response.data.quantityOnHand,
                    price:response.data.price,
                    j:true,
                    text:"update"
                })
            }
        )
    }

    onSubmit(product){
        if(this.state.productId!==" ")
        ProductDataService.updateProduct(product).then(()=>{
          
            this.props.history.push("/products")
        })
        else
        ProductDataService.saveProduct(product).then(()=>this.props.history.push("/products"))
        console.log(product)
    }

    validateProductForm(values){
        let errors={}
        if(!values.productId){
            errors.productId="Enter a product Name"
        }
        else if(!values.productName){
            errors.productName="Enter a product Name"
        }
        else if(!values.quantityOnHand){
            errors.quantityOnHand="Enter quantity"
        }
        else if(!values.price){
            errors.price="Enter price"
        }
        else if(values.price<0){
            errors.price="price cannot be negative"
        }
        else if(values.productName.length<5){
            errors.productName="Enter atleast 5 characters"
        }
        return errors;
    }
    render() {
        let{productId,productName,quantityOnHand,price}=this.state
        return (
            <div>
                <h2>Add/update component</h2>
                <h2>update productId:{this.state.productId}</h2>
                {/* <div>{productId}</div>
                <div>{productName}</div>
                <div>{quantityOnHand}</div>
                <div>{price}</div> */}
                <Formik
                initialValues={{productId,productName,quantityOnHand,price}}
                enableReinitialize={true} onSubmit={this.onSubmit} validateOnBlur={false} validateOnChange={false}
                validate={this.validateProductForm}>
                    <Form>
                        <ErrorMessage name="productId" component="div"
                        className="alert alert-warning"></ErrorMessage>

                        <ErrorMessage name="productName" component="div"
                        className="alert alert-warning"></ErrorMessage>

                        <ErrorMessage name="quantityOnHand" component="div"
                        className="alert alert-warning"></ErrorMessage>

                        <ErrorMessage name="price" component="div"
                        className="alert alert-warning"></ErrorMessage>
                        

                        <fieldset className="form-group">
                            <label>Product Id</label>
                            <Field className="form-control" type="text" name="productId" disabled={this.state.j} ></Field>
                        </fieldset>

                        <fieldset className="form-group">
                            <label>Product Name</label>
                            <Field className="form-control" type="text" name="productName"></Field>
                        </fieldset>

                        <fieldset className="form-group">
                            <label>quantityOnHand</label>
                            <Field className="form-control" type="text" name="quantityOnHand"></Field>
                        </fieldset>

                        <fieldset className="form-group">
                            <label>price</label>
                            <Field className="form-control" type="text" name="price"></Field>
                        </fieldset>
                        <button type="submit" className="btn btn-success">{this.state.text}</button>
                    </Form>
                </Formik>
            </div>
        );
    }
}

export default ProductComponent;