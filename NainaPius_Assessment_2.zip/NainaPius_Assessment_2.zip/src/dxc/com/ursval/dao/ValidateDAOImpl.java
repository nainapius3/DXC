package dxc.com.ursval.dao;




import com.dxc.usrval.client.UserApp;
import com.dxc.usrval.dbcom.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ValidateDAOImpl implements ValidateDAO {
	private static final String FETCH_USER_ALL = "select * from userinfo where Name=? and Password=?";
	Connection connection = DbConnection.getConnection();
public ValidateDAOImpl() {
	}
	@Override
	public boolean isUserExists(UserApp user) {
		boolean userExists = false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(FETCH_USER_ALL);
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getPassword());
			ResultSet res = preparedStatement.executeQuery();
			if (res.next()) {
				userExists = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return userExists;
	}

}
