package com.dxc.model;

public class Doctor {
	
	private int docId;
	private String name;
	private int fees;
	private String HospitalName;
	private String HospitalCity;


	public void Doctor(int docId, String name, int fees, String hospitalName, String hospitalCity) {
		
		this.docId = docId;
		this.name = name;
		this.fees = fees;
		HospitalName = hospitalName;
		HospitalCity = hospitalCity;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public String getHospitalName() {
		return HospitalName;
	}
	public void setHospitalName(String hospitalName) {
		HospitalName = hospitalName;
	}
	public String getHospitalCity() {
		return HospitalCity;
	}
	public void setHospitalCity(String hospitalCity) {
		HospitalCity = hospitalCity;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((HospitalCity == null) ? 0 : HospitalCity.hashCode());
		result = prime * result + ((HospitalName == null) ? 0 : HospitalName.hashCode());
		result = prime * result + docId;
		result = prime * result + fees;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor1 other = (Doctor1) obj;
		if (HospitalCity == null) {
			if (other.HospitalCity != null)
				return false;
		} else if (!HospitalCity.equals(other.HospitalCity))
			return false;
		if (HospitalName == null) {
			if (other.HospitalName != null)
				return false;
		} else if (!HospitalName.equals(other.HospitalName))
			return false;
		if (docId != other.docId)
			return false;
		if (fees != other.fees)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "DoctorDetails [docId=" + docId + ", name=" + name + ", fees=" + fees + ", HospitalName=" + HospitalName
				+ ", HospitalCity=" + HospitalCity + "]";
	}
	
	
}