package dxc.com.ursval.dao;



import com.dxc.usrval.client.UserApp;


public interface ValidateDAO {
public boolean isUserExists(UserApp user);
}

