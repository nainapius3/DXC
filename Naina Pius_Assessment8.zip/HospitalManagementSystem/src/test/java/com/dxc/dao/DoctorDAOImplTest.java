package com.dxc.dao;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

}
