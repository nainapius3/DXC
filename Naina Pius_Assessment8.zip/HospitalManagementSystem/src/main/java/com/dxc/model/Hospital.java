package com.dxc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Doc100")
public class Hospital {
	

	
	@Column (name="Dname")
	private String HospitalName;
	private String HospitalCity;
	public Hospital(String hospitalName, String hospitalCity) {
		super();
		HospitalName = hospitalName;
		HospitalCity = hospitalCity;
	}
	public String getHospitalName() {
		return HospitalName;
	}
	public void setHospitalName(String hospitalName) {
		HospitalName = hospitalName;
	}
	public String getHospitalCity() {
		return HospitalCity;
	}
	public void setHospitalCity(String hospitalCity) {
		HospitalCity = hospitalCity;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((HospitalCity == null) ? 0 : HospitalCity.hashCode());
		result = prime * result + ((HospitalName == null) ? 0 : HospitalName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hospital other = (Hospital) obj;
		if (HospitalCity == null) {
			if (other.HospitalCity != null)
				return false;
		} else if (!HospitalCity.equals(other.HospitalCity))
			return false;
		if (HospitalName == null) {
			if (other.HospitalName != null)
				return false;
		} else if (!HospitalName.equals(other.HospitalName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "HospitalDetails [HospitalName=" + HospitalName + ", HospitalCity=" + HospitalCity + "]";
	}

	
	
}