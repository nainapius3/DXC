var express = require("express")
var app = express();
var fs=require('fs')
// we cant retrieve dynamic data from HTML pages, so we need to go to a file which returns JSX format
// for that add another template "ejs"/view engine

app.set('view engine','ejs');

app.get("/", function(request,response){
    // var myReadStream =fs.createReadStream(__dirname+'/resource/about.txt','utf-8');


var readStream = fs.readFileSync(__dirname+'/about.txt', 'utf8');

// readStream.on('data', function(chunk) {
//     data += chunk;
// })
console.log(readStream);
 response.render("about",{
                
 data : readStream,

    });
})
 
console.log("Server started on port : 5001")
app.listen(5001);