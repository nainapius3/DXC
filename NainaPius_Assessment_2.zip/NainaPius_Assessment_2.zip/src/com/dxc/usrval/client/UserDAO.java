package com.dxc.usrval.client;

public class UserDAO {

}
