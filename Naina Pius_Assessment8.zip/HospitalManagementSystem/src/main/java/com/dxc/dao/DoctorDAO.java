package com.dxc.dao;

import org.hibernate.mapping.List;

import com.dxc.model.Doctor;

public interface DoctorDAO {
	
	public Doctor getDoctor(int docID);
	public List getAllDoctors();
	public void addDoctor(Doctor doctor);
	public void deleteDoctor(int docID);
	public void updateDoctor(Doctor doctor);
	void deleteProduct(int docId);


}



