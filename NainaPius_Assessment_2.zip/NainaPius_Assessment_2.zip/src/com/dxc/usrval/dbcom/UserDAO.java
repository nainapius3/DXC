package com.dxc.usrval.dbcom;

public interface UserDAO {

}
